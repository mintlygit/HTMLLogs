# HTMLLogs — интерактивный просмотр логов в HTML
### HTMLLogs — это лёгкая библиотека для Python, которая перехватывает логи из стандартного модуля logging и в реальном времени генерирует красивый интерактивный HTML-файл. Фильтрация по уровню (Error/Warning/Info/Debug), поиск по сообщению, сортировка по столбцам и подсветка JSON-объектов прямо в браузере.

## Возможности
- Интерактивная таблица с фильтрацией, поиском и сортировкой.
- Подсветка JSON в сообщениях для удобного чтения.
- Автообновление HTML — файл перезаписывается при каждом новом логе.
- Ограниченное хранилище — до max_records записей (по умолчанию 1000), без переполнения памяти.
- Простая настройка — достаточно одной строки.

### Установка
```bash
pip install htmllogs
```
### Быстрый старт
```python
import logging
import htmllogs

#Настройка LN (!!!по умолчанию файл logs.html!!!)
htmllogs.setup()

logging.info("Приложение запущено")
logging.debug("Отладочное сообщение")
logging.warning("Внимание!")
try:
    1 / 0
except ZeroDivisionError:
    logging.error("Ошибка деления на ноль", exc_info=True)
```
Откройте файл logs.html в браузере — логи отобразятся в чистой интерактивной таблице.

### Настройка
```python
htmllogs.setup(html_file='logs.html', level=logging.DEBUG, max_records=1000)
```
- html_file — путь к выходному HTML-файлу (по умолчанию 'logs.html').
 - level — минимальный уровень логирования (например, logging.INFO).
  - max_records — максимальное количество записей, хранящихся в памяти и отображаемых в HTML.

## Расширенное использование
### Можно использовать htmllogsHandler напрямую с любым логгером:
```python
import logging
from htmllogs import htmllogsHandler

handler = htmllogsHandler('my_logs.html', max_records=500)
logger = logging.getLogger('myapp')
logger.addHandler(handler)
logger.setLevel(logging.DEBUG)
```

### Использование конфигурационного файла
Сохраните настройки в JSON-файл, например htmllogs_config.json:
```json
{
    "html_file": "my_logs.html",
    "level": "INFO",
    "max_records": 500
}
```
Затем примените их:

```python
import logging
import htmllogs
from htmllogs import Config

cfg = Config('htmllogs_config.json')
htmllogs.setup(cfg.html_file, getattr(logging, cfg.level), cfg.max_records)
```

# Как это работает?
## htmllogs устанавливает собственный обработчик, который сохраняет записи логов в кольцевой буфер и формирует HTML-файл со встроенным JavaScript. Таблица поддерживает:
### - Фильтрацию по уровню (нажмите на бейдж уровня)
### - Поиск по тексту
### - Сортировку по времени, уровню, имени логгера, сообщению
### - Обнаружение JSON — JSON-строки автоматически форматируются и подсвечиваются
Файл обновляется при каждом новом логе, поэтому вы можете держать его открытым в браузере и наблюдать за логами в реальном времени.